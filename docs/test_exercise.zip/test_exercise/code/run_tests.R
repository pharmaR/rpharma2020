# Test execution
report <- testthat::test_dir(filepath, reporter = testthat::ListReporter)
