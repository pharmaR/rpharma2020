# Set-up
pkgs <- c("tidyverse", "devtools")
install.packages(pkgs)

